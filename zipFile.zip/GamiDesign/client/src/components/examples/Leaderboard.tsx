import Leaderboard from '../Leaderboard';

export default function LeaderboardExample() {
  return (
    <div className="p-6 max-w-md">
      <Leaderboard />
    </div>
  );
}
